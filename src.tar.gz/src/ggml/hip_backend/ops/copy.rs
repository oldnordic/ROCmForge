//! HIP op stub.
