//! HIP buffer glue for ggml backend.
