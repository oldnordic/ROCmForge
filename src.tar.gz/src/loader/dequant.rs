//! Quantization and dequantization functions
//!
//! DEPRECATED: This module re-exports from `crate::kernels::quant`.
//! The CPU dequantization implementations have been moved to the kernels module
//! for better organization (Phase 24-02). GPU dequantization remains in
//! `ggml::hip_backend::ops`.

use super::gguf_tensor::GgufTensor;
use super::mxfp::MxfpBlock;
use super::tensor_type::GgufTensorType;
use anyhow::Result;

// Re-export Q8_0 from kernels
pub use crate::kernels::quant::q8_0::dequantize_q8_0 as dequant_q8_0_kernel;

/// Dequantize Q8_0 tensor to FP32 (parallelized with Rayon)
///
/// Re-exports from `crate::kernels::quant::q8_0`.
/// This function maintains the original API for backward compatibility.
#[deprecated(note = "Use crate::kernels::quant::dequantize_q8_0 directly")]
#[allow(dead_code)] // Backward compatibility wrapper - consumers should migrate to crate::kernels::quant::dequantize_q8_0
pub fn dequant_q8_0(tensor: &GgufTensor) -> Result<Vec<f32>> {
    dequant_q8_0_kernel(&tensor.data, tensor.total_elements())
        .map_err(|e| anyhow::anyhow!("Q8_0 dequantization failed: {}", e))
}

// Re-export Q4_0 from kernels
pub use crate::kernels::quant::q4_0::dequantize_q4_0_cpu as dequant_q4_0_kernel;

/// Dequantize Q4_0 tensor to FP32
///
/// Re-exports from `crate::kernels::quant::q4_0`.
/// This function maintains the original API for backward compatibility.
#[deprecated(note = "Use crate::kernels::quant::dequantize_q4_0_cpu directly")]
#[allow(dead_code)] // Backward compatibility wrapper - consumers should migrate to crate::kernels::quant::dequantize_q4_0_cpu
pub fn dequant_q4_0(tensor: &GgufTensor) -> Result<Vec<f32>> {
    Ok(dequant_q4_0_kernel(&tensor.data, tensor.total_elements()))
}

/// Dequantize MXFP4 tensor to FP32
pub fn dequant_mxfp4(tensor: &GgufTensor) -> Result<Vec<f32>> {
    let total_elements = tensor.total_elements();
    let mut result = vec![0.0f32; total_elements];
    let blocks = total_elements.div_ceil(32);

    for block_idx in 0..blocks {
        let block_start = block_idx * 17; // 1 scale byte + 16 data bytes

        if block_start + 1 > tensor.data.len() {
            break;
        }

        // Read scale (E8M0)
        let scale_exp = tensor.data[block_start] as i8;
        let scale = 2.0_f32.powi(scale_exp as i32);

        // Read MXFP4 elements (4-bit packed)
        let data_start = block_start + 1;
        let data_end = std::cmp::min(data_start + 16, tensor.data.len());

        for (byte_offset, &packed) in tensor.data[data_start..data_end].iter().enumerate() {
            for j in 0..2 {
                let element_idx = block_idx * 32 + byte_offset * 2 + j;
                if element_idx < total_elements {
                    let e2m1_bits = if j == 0 {
                        (packed >> 4) & 0x0F
                    } else {
                        packed & 0x0F
                    };

                    // Decode E2M1
                    let decoded = MxfpBlock::decode_e2m1(e2m1_bits);
                    let mut val = scale * decoded;
                    val = val.clamp(-8.0, 8.0); // MXFP4 range per OCP MX Spec v1.0
                    result[element_idx] = val;
                }
            }
        }
    }

    Ok(result)
}

/// Dequantize MXFP6 tensor to FP32
pub fn dequant_mxfp6(tensor: &GgufTensor) -> Result<Vec<f32>> {
    let total_elements = tensor.total_elements();
    let mut result = vec![0.0f32; total_elements];
    let blocks = total_elements.div_ceil(32);

    for block_idx in 0..blocks {
        let block_start = block_idx * 25; // 1 scale byte + 24 data bytes

        if block_start + 1 > tensor.data.len() {
            break;
        }

        // Read scale (E8M0)
        let scale_exp = tensor.data[block_start] as i8;
        let scale = 2.0_f32.powi(scale_exp as i32);

        // Read MXFP6 elements (6-bit packed)
        let data_start = block_start + 1;
        let data_end = std::cmp::min(data_start + 24, tensor.data.len());
        let packed_data = &tensor.data[data_start..data_end];

        // Unpack 6-bit values
        for i in 0..32 {
            let element_idx = block_idx * 32 + i;
            if element_idx >= total_elements {
                break;
            }

            // Extract 6-bit value
            let bit_offset = (i * 6) % 8;
            let byte_idx = (i * 6) / 8;

            if byte_idx + 1 < packed_data.len() {
                let combined =
                    ((packed_data[byte_idx + 1] as u16) << 8) | (packed_data[byte_idx] as u16);
                let e2m3_bits = ((combined >> (10 - bit_offset)) & 0x3F) as u8;

                // Decode E2M3
                let decoded = MxfpBlock::decode_e2m3(e2m3_bits);
                let mut val = scale * decoded;
                val = val.clamp(-7.5, 7.5); // MXFP6 range
                result[element_idx] = val;
            }
        }
    }

    Ok(result)
}

// Re-export Q4_K from kernels
pub use crate::kernels::quant::q4_k::dequantize_q4_k_cpu as dequant_q4_k_kernel;

/// Dequantize Q4_K tensor to FP32
///
/// Re-exports from `crate::kernels::quant::q4_k`.
/// This function maintains the original API for backward compatibility.
#[deprecated(note = "Use crate::kernels::quant::dequantize_q4_k_cpu directly")]
#[allow(dead_code)] // Backward compatibility wrapper - consumers should migrate to crate::kernels::quant::dequantize_q4_k_cpu
pub fn dequant_q4_k(tensor: &GgufTensor) -> Result<Vec<f32>> {
    Ok(dequant_q4_k_kernel(&tensor.data, tensor.total_elements()))
}

/// Dequantize Q5_K tensor to FP32
/// Q5_K uses super-block structure with 256-byte blocks
/// Format: 16 half-precision scales + 16 int8 mins + 160 bytes 5-bit quants + 48 bytes additional
pub fn dequant_q5_k(tensor: &GgufTensor) -> Result<Vec<f32>> {
    let total_elements = tensor.total_elements();
    let mut result = vec![0.0f32; total_elements];
    let blocks = total_elements.div_ceil(256);

    for block_idx in 0..blocks {
        let block_start = block_idx * 256;

        if block_start + 256 > tensor.data.len() {
            break;
        }

        // Q5_K super-block structure:
        // - 32 bytes: 16 half-precision scales (2 bytes each) for 16 sub-blocks
        // - 16 bytes: 16 int8 mins (1 byte each) for 16 sub-blocks
        // - 160 bytes: 16 sub-blocks of 5-bit quantized values (10 bytes each)
        // - 48 bytes: additional data

        let scales_start = block_start;
        let mins_start = block_start + 32;
        let quants_start = block_start + 48;

        // Process each of the 16 sub-blocks (16 elements each)
        for sub_block_idx in 0..16 {
            let sub_block_start = block_idx * 256 + sub_block_idx * 16;

            // Get scale for this sub-block
            let scale_offset = scales_start + sub_block_idx * 2;
            let scale = if scale_offset + 2 <= tensor.data.len() {
                let scale_bits = u16::from_le_bytes([
                    tensor.data[scale_offset],
                    tensor.data[scale_offset + 1],
                ]);
                half::f16::from_bits(scale_bits).to_f32()
            } else {
                1.0
            };

            // Get min for this sub-block
            let min_offset = mins_start + sub_block_idx;
            let min = if min_offset < tensor.data.len() {
                tensor.data[min_offset] as i8 as f32
            } else {
                0.0
            };

            // Extract 5-bit quantized values for this sub-block (16 values)
            for i in 0..16 {
                let element_idx = sub_block_start + i;
                if element_idx >= total_elements {
                    break;
                }

                // 5-bit values packed: 16 values * 5 bits = 80 bits = 10 bytes
                let bit_pos = i * 5;
                let byte_idx = bit_pos / 8;
                let bit_offset = bit_pos % 8;

                let quant_offset = quants_start + sub_block_idx * 10 + byte_idx;

                let quant = if quant_offset + 2 <= tensor.data.len() {
                    // Read 16 bits to ensure we can extract 5 bits that may span 2 bytes
                    let combined = ((tensor.data[quant_offset + 1] as u16) << 8)
                                   | (tensor.data[quant_offset] as u16);
                    ((combined >> bit_offset) & 0x1F) as u8
                } else {
                    0
                };

                result[element_idx] = min + (quant as f32) * scale;
            }
        }
    }

    Ok(result)
}

// Re-export Q6_K from kernels
pub use crate::kernels::quant::q6_k::dequantize_q6_k_cpu as dequant_q6_k_kernel;

/// Dequantize Q6_K tensor to FP32
///
/// Re-exports from `crate::kernels::quant::q6_k`.
/// This function maintains the original API for backward compatibility.
#[deprecated(note = "Use crate::kernels::quant::dequantize_q6_k_cpu directly")]
#[allow(dead_code)] // Backward compatibility wrapper - consumers should migrate to crate::kernels::quant::dequantize_q6_k_cpu
pub fn dequant_q6_k(tensor: &GgufTensor) -> Result<Vec<f32>> {
    Ok(dequant_q6_k_kernel(&tensor.data, tensor.total_elements()))
}

/// Dequantize Q3_K tensor to FP32
/// Q3_K uses super-block structure with 256-byte blocks
/// Format: scales + quants with 3-bit packed values
pub fn dequant_q3_k(tensor: &GgufTensor) -> Result<Vec<f32>> {
    let total_elements = tensor.total_elements();
    let mut result = vec![0.0f32; total_elements];
    let blocks = total_elements.div_ceil(256);

    for block_idx in 0..blocks {
        let block_start = block_idx * 256;

        if block_start + 256 > tensor.data.len() {
            break;
        }

        // Q3_K super-block structure:
        // - 32 bytes: 16 half-precision scales (2 bytes each) for 16 sub-blocks
        // - 4 bytes: qh (high bits for 3-bit quants)
        // - 160 bytes: 3-bit quantized values (256 * 3 / 8 = 96 bytes, but padded)
        // - 60 bytes: additional data

        let scales_start = block_start;
        let qh_start = block_start + 32;
        let quants_start = block_start + 36;

        // Process each of the 16 sub-blocks (16 elements each)
        for sub_block_idx in 0..16 {
            let sub_block_start = block_idx * 256 + sub_block_idx * 16;

            // Get scale for this sub-block
            let scale_offset = scales_start + sub_block_idx * 2;
            let scale = if scale_offset + 2 <= tensor.data.len() {
                let scale_bits = u16::from_le_bytes([
                    tensor.data[scale_offset],
                    tensor.data[scale_offset + 1],
                ]);
                half::f16::from_bits(scale_bits).to_f32()
            } else {
                1.0
            };

            // Read high bits (qh) - 2 bits per element
            let qh_offset = qh_start + sub_block_idx / 4;
            let qh_shift = (sub_block_idx % 4) * 2;
            let qh = if qh_offset < tensor.data.len() {
                (tensor.data[qh_offset] >> qh_shift) & 0x03
            } else {
                0
            };

            // Extract 3-bit quantized values for this sub-block (16 values)
            for i in 0..16 {
                let element_idx = sub_block_start + i;
                if element_idx >= total_elements {
                    break;
                }

                // 3-bit values packed: 16 values * 3 bits = 48 bits = 6 bytes per sub-block
                let bit_pos = i * 3;
                let byte_idx = bit_pos / 8;
                let bit_offset = bit_pos % 8;

                let quant_offset = quants_start + sub_block_idx * 6 + byte_idx;

                let quant = if quant_offset + 1 < tensor.data.len() {
                    let combined = ((tensor.data[quant_offset + 1] as u16) << 8)
                                   | (tensor.data[quant_offset] as u16);
                    let low_bits = ((combined >> bit_offset) & 0x07) as u8;

                    // Combine with high bits from qh
                    let high_bit = if i < 8 { (qh >> i) & 1 } else { 0 };
                    (low_bits | (high_bit << 3)) as i8 as f32 - 4.0
                } else {
                    0.0
                };

                result[element_idx] = quant * scale;
            }
        }
    }

    Ok(result)
}

/// Dequantize Q2_K tensor to FP32
/// Q2_K uses super-block structure with 256-byte blocks (most complex K-quant format)
pub fn dequant_q2_k(tensor: &GgufTensor) -> Result<Vec<f32>> {
    let total_elements = tensor.total_elements();
    let mut result = vec![0.0f32; total_elements];
    let blocks = total_elements.div_ceil(256);

    for block_idx in 0..blocks {
        let block_start = block_idx * 256;

        if block_start + 256 > tensor.data.len() {
            break;
        }

        // Q2_K super-block structure:
        // - 32 bytes: 16 half-precision scales (2 bytes each)
        // - 32 bytes: 16 half-precision mins (2 bytes each)
        // - 4 bytes: qh (high bits for 2-bit quants)
        // - 136 bytes: 2-bit quantized values (256 * 2 / 8 = 64 bytes + padding)
        // - 52 bytes: additional data

        let scales_start = block_start;
        let mins_start = block_start + 32;
        let qh_start = block_start + 64;
        let quants_start = block_start + 68;

        // Process each of the 16 sub-blocks (16 elements each)
        for sub_block_idx in 0..16 {
            let sub_block_start = block_idx * 256 + sub_block_idx * 16;

            // Get scale for this sub-block
            let scale_offset = scales_start + sub_block_idx * 2;
            let scale = if scale_offset + 2 <= tensor.data.len() {
                let scale_bits = u16::from_le_bytes([
                    tensor.data[scale_offset],
                    tensor.data[scale_offset + 1],
                ]);
                half::f16::from_bits(scale_bits).to_f32()
            } else {
                1.0
            };

            // Get min for this sub-block
            let min_offset = mins_start + sub_block_idx * 2;
            let min = if min_offset + 2 <= tensor.data.len() {
                let min_bits = u16::from_le_bytes([
                    tensor.data[min_offset],
                    tensor.data[min_offset + 1],
                ]);
                half::f16::from_bits(min_bits).to_f32()
            } else {
                0.0
            };

            // Read high bits (qh) - Q2_K has 1 high bit per pair of elements
            let qh_offset = qh_start + sub_block_idx / 8;
            let qh_shift = (sub_block_idx % 8) * 1;
            let qh = if qh_offset < tensor.data.len() {
                (tensor.data[qh_offset] >> qh_shift) & 0x01
            } else {
                0
            };

            // Extract 2-bit quantized values for this sub-block (16 values)
            for i in 0..16 {
                let element_idx = sub_block_start + i;
                if element_idx >= total_elements {
                    break;
                }

                // 2-bit values packed: 16 values * 2 bits = 32 bits = 4 bytes per sub-block
                let bit_pos = i * 2;
                let byte_idx = bit_pos / 8;
                let bit_offset = bit_pos % 8;

                let quant_offset = quants_start + sub_block_idx * 4 + byte_idx;

                let quant = if quant_offset + 1 < tensor.data.len() {
                    let combined = ((tensor.data[quant_offset + 1] as u16) << 8)
                                   | (tensor.data[quant_offset] as u16);
                    let low_bits = ((combined >> bit_offset) & 0x03) as u8;

                    // Combine with high bit from qh
                    let high_bit = if i < 8 { (qh >> i) & 1 } else { 0 };
                    (low_bits | (high_bit << 2)) as i8 as f32
                } else {
                    0.0
                };

                result[element_idx] = min + quant * scale;
            }
        }
    }

    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::loader::gguf_tensor::GgufTensor;
    use crate::loader::tensor_type::GgufTensorType;
    use crate::loader::TensorShape;

    fn create_test_tensor(tensor_type: GgufTensorType, data: Vec<u8>, shape: Vec<usize>) -> GgufTensor {
        GgufTensor {
            name: "test".to_string(),
            tensor_type,
            shape: TensorShape::from_dims(&shape),
            quant_type: tensor_type.to_string().to_string(),
            data,
            offset: 0,
        }
    }

    #[test]
    fn test_dequant_q5_k_zeros() {
        // Test Q5_K with all zeros
        let mut data = vec![0u8; 256];

        // Set a single scale (half precision 1.0)
        data[0] = 0x00;
        data[1] = 0x3C; // 1.0 in half precision

        let tensor = create_test_tensor(GgufTensorType::Q5_K, data, vec![256]);
        let result = dequant_q5_k(&tensor).unwrap();

        assert_eq!(result.len(), 256);
        // All values should be 0 (min + quant * scale where quant = 0)
        for (i, val) in result.iter().enumerate() {
            assert!(
                val.abs() < 1e-6,
                "Zero test mismatch at {}: expected ~0, got {}",
                i, val
            );
        }
    }

    #[test]
    fn test_dequant_q5_k_positive() {
        // Test Q5_K with known positive values
        let mut data = vec![0u8; 256];

        // Set scale = 1.0 in half precision (0x3C00)
        data[0] = 0x00;
        data[1] = 0x3C;

        // Set min = 0 (already 0 from initialization)

        // Set quantized values to known pattern
        // Q5_K: 16 sub-blocks, 16 elements each, 5 bits per element
        // First sub-block (elements 0-15): set quants to 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16
        // Packed: 1<<0 | 2<<5 | 3<<10 | 4<<15 | 5<<20 | 6<<25 | 7<<30 | ...
        // This is complex, so let's use a simpler pattern

        // Set first quant to 1 (bit 0-4), second quant to 0
        data[48] = 0x01; // First 5 bits = 1

        let tensor = create_test_tensor(GgufTensorType::Q5_K, data, vec![256]);
        let result = dequant_q5_k(&tensor).unwrap();

        assert_eq!(result.len(), 256);
        // First element should be ~1 (min=0, quant=1, scale=1.0)
        assert!((result[0] - 1.0).abs() < 0.1, "First element: {}", result[0]);
        // Rest should be ~0
        for i in 1..16 {
            assert!(result[i].abs() < 0.1, "Element at {}: {}", i, result[i]);
        }
    }

    #[test]
    fn test_dequant_q5_k_partial_block() {
        // Test Q5_K with partial block
        let mut data = vec![0u8; 256];

        // Set scale = 1.0
        data[0] = 0x00;
        data[1] = 0x3C;

        let tensor = create_test_tensor(GgufTensorType::Q5_K, data, vec![100]);
        let result = dequant_q5_k(&tensor).unwrap();

        assert_eq!(result.len(), 100);
        // All should be ~0 with zeros data
        for val in &result[..100] {
            assert!(val.abs() < 1e-6);
        }
    }

    #[test]
    fn test_dequant_q5_k_multiple_blocks() {
        // Test Q5_K with multiple blocks
        let mut data = vec![0u8; 512]; // 2 blocks

        // Block 1: scale = 1.0, all zeros
        data[0] = 0x00;
        data[1] = 0x3C;

        // Block 2: scale = 2.0 (half precision)
        data[256] = 0x00;
        data[257] = 0x40;

        // Set some non-zero quants in second block (first quant = 31)
        data[256 + 48] = 0xFF; // Lower 5 bits set = 31
        data[256 + 48 + 1] = 0x80; // Next 5 bits start here

        let tensor = create_test_tensor(GgufTensorType::Q5_K, data, vec![512]);
        let result = dequant_q5_k(&tensor).unwrap();

        assert_eq!(result.len(), 512);
        // First block should be ~0
        for i in 0..256 {
            assert!(result[i].abs() < 1e-5, "Block 1 at {}: {}", i, result[i]);
        }
        // Second block first element should be ~31 * 2.0
        assert!((result[256] - 62.0).abs() < 1.0, "Block 2 first: {}", result[256]);
    }

    #[test]
    fn test_dequant_q3_k_zeros() {
        // Test Q3_K with all zeros
        let mut data = vec![0u8; 256];

        // Set scale = 1.0 in half precision
        data[0] = 0x00;
        data[1] = 0x3C;

        let tensor = create_test_tensor(GgufTensorType::Q3_K, data, vec![256]);
        let result = dequant_q3_k(&tensor).unwrap();

        assert_eq!(result.len(), 256);
        // With zeros, quant=0, so result = (0 - 4) * 1.0 = -4.0
        for val in &result[..16] {
            assert!((val - (-4.0)).abs() < 0.1, "Expected -4.0, got {}", val);
        }
    }

    #[test]
    fn test_dequant_q3_k_positive() {
        // Test Q3_K with known values
        let mut data = vec![0u8; 256];

        // Set scale = 1.0
        data[0] = 0x00;
        data[1] = 0x3C;

        // Set first quant to 1 (bit 0-2)
        data[36] = 0x01; // First 3 bits = 1

        let tensor = create_test_tensor(GgufTensorType::Q3_K, data, vec![256]);
        let result = dequant_q3_k(&tensor).unwrap();

        assert_eq!(result.len(), 256);
        // First element: quant=1, result = (1 - 4) = -3
        assert!((result[0] - (-3.0)).abs() < 0.1, "First element: {}", result[0]);
        // Rest of first sub-block should be -4 (quant=0)
        for i in 1..16 {
            assert!((result[i] - (-4.0)).abs() < 0.1, "Element at {}: {}", i, result[i]);
        }
    }

    #[test]
    fn test_dequant_q3_k_partial_block() {
        // Test Q3_K with partial block (less than 256 elements)
        let mut data = vec![0u8; 256];

        data[0] = 0x00;
        data[1] = 0x3C;

        let tensor = create_test_tensor(GgufTensorType::Q3_K, data, vec![100]);
        let result = dequant_q3_k(&tensor).unwrap();

        assert_eq!(result.len(), 100);
        // First 100 elements should be -4 (quant=0, offset=-4)
        // Only check first sub-block (16 elements) since that's where our test data is
        for i in 0..16usize {
            if i < 100 {
                assert!((result[i] - (-4.0)).abs() < 0.1, "Element at {}: {}", i, result[i]);
            }
        }
    }

    #[test]
    fn test_dequant_q2_k_zeros() {
        // Test Q2_K with all zeros
        let mut data = vec![0u8; 256];

        // Set scale = 1.0 in half precision
        data[0] = 0x00;
        data[1] = 0x3C;

        // Min is already 0 from initialization

        let tensor = create_test_tensor(GgufTensorType::Q2_K, data, vec![256]);
        let result = dequant_q2_k(&tensor).unwrap();

        assert_eq!(result.len(), 256);
        // All should be 0 (min=0, quant=0, scale=1.0)
        for val in &result[..16] {
            assert!(val.abs() < 1e-5);
        }
    }

    #[test]
    fn test_dequant_q2_k_positive() {
        // Test Q2_K with known values
        let mut data = vec![0u8; 256];

        // Set scale = 1.0
        data[0] = 0x00;
        data[1] = 0x3C;

        // Set first quant to 1 (bit 0-1)
        data[68] = 0x01; // First 2 bits = 1

        let tensor = create_test_tensor(GgufTensorType::Q2_K, data, vec![256]);
        let result = dequant_q2_k(&tensor).unwrap();

        assert_eq!(result.len(), 256);
        // First element should be ~1 (min=0, quant=1, scale=1)
        assert!((result[0] - 1.0).abs() < 0.1, "First element: {}", result[0]);
    }

    #[test]
    fn test_dequant_q2_k_partial_block() {
        // Test Q2_K with partial block
        let mut data = vec![0u8; 256];

        data[0] = 0x00;
        data[1] = 0x3C;

        let tensor = create_test_tensor(GgufTensorType::Q2_K, data, vec![100]);
        let result = dequant_q2_k(&tensor).unwrap();

        assert_eq!(result.len(), 100);
        // Should all be ~0
        for i in 0..16usize {
            if i < 100 {
                assert!(result[i].abs() < 1e-5, "Element at {}: {}", i, result[i]);
            }
        }
    }
}

/// Generic dequantization dispatcher
///
/// Routes to the appropriate dequantization function based on tensor type.
/// Migrated to use kernel module functions directly (26-01) to eliminate
/// deprecation warnings.
pub fn dequantize(tensor: &GgufTensor) -> Result<Vec<f32>> {
    match tensor.tensor_type {
        GgufTensorType::F32 => Ok(tensor
            .data
            .chunks_exact(4)
            .map(|chunk| f32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]))
            .collect()),
        GgufTensorType::F16 => Ok(tensor
            .data
            .chunks_exact(2)
            .map(|chunk| {
                let bits = u16::from_le_bytes([chunk[0], chunk[1]]);
                half::f16::from_bits(bits).to_f32()
            })
            .collect()),
        // Use kernel module functions directly (migrated in 26-01)
        GgufTensorType::Q8_0 => crate::kernels::quant::dequantize_q8_0(&tensor.data, tensor.total_elements())
            .map_err(|e| anyhow::anyhow!("Q8_0 dequantization failed: {}", e)),
        GgufTensorType::Q4_0 => Ok(crate::kernels::quant::dequantize_q4_0_cpu(&tensor.data, tensor.total_elements())),
        GgufTensorType::Mxfp4 => dequant_mxfp4(tensor),
        GgufTensorType::Mxfp6E2m3 | GgufTensorType::Mxfp6E3m2 => dequant_mxfp6(tensor),
        GgufTensorType::Q2_K => dequant_q2_k(tensor),
        GgufTensorType::Q3_K => dequant_q3_k(tensor),
        GgufTensorType::Q4_K => Ok(crate::kernels::quant::dequantize_q4_k_cpu(&tensor.data, tensor.total_elements())),
        GgufTensorType::Q5_K => dequant_q5_k(tensor),
        GgufTensorType::Q6_K => Ok(crate::kernels::quant::dequantize_q6_k_cpu(&tensor.data, tensor.total_elements())),
    }
}
