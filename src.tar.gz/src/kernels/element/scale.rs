//! HIP add/scale kernel wrappers
//!
//! Provides element-wise tensor scaling and addition operations using hipBLAS.

use crate::backend::{
    hip_blas, hip_blas::HipBlasHandle, HipBackend, HipError, HipBuffer, HipResult,
};

fn set_stream(handle: &HipBlasHandle, backend: &HipBackend) -> HipResult<()> {
    handle
        .set_stream(backend.stream().as_ptr())
        .map_err(|e| HipError::GenericError(format!("Failed to set hipBLAS stream: {}", e)))
}

/// Element-wise addition: output = a + b
///
/// Uses hipBLAS saxpy for efficient GPU computation.
///
/// # Arguments
/// * `backend` - HIP backend for stream management
/// * `a` - First input buffer
/// * `b` - Second input buffer
/// * `output` - Output buffer (must be same size as inputs)
///
/// # Returns
/// * `Ok(())` on success
/// * `Err(HipError)` if buffer sizes don't match or operation fails
pub fn add(
    backend: &HipBackend,
    a: &HipBuffer,
    b: &HipBuffer,
    output: &HipBuffer,
) -> HipResult<()> {
    if a.size() != b.size() || a.size() != output.size() {
        return Err(HipError::GenericError(
            "Add requires equal-sized buffers".to_string(),
        ));
    }

    // output = a
    // Use stream-aware copy for consistency with backend.stream()
    output.copy_from_buffer_with_stream(a, backend.stream().as_ptr())?;

    // output += b
    let handle = HipBlasHandle::new()
        .map_err(|e| HipError::GenericError(format!("Failed to create hipBLAS handle: {}", e)))?;
    set_stream(&handle, backend)?;

    let n = (output.size() / std::mem::size_of::<f32>()) as i32;
    hip_blas::saxpy(
        &handle,
        n,
        1.0f32,
        b.as_ptr() as *const f32,
        1,
        output.as_ptr() as *mut f32,
        1,
    )
    .map_err(|e| HipError::GenericError(format!("hipBLAS saxpy failed: {}", e)))?;
    Ok(())
}

/// Element-wise scaling: output = input * factor
///
/// Uses hipBLAS sscal for efficient GPU computation.
///
/// # Arguments
/// * `backend` - HIP backend for stream management
/// * `input` - Input buffer
/// * `factor` - Scalar multiplication factor
/// * `output` - Output buffer (must be same size as input)
///
/// # Returns
/// * `Ok(())` on success
/// * `Err(HipError)` if buffer sizes don't match or operation fails
pub fn scale(
    backend: &HipBackend,
    input: &HipBuffer,
    factor: f32,
    output: &HipBuffer,
) -> HipResult<()> {
    if input.size() != output.size() {
        return Err(HipError::GenericError(
            "Scale requires equal-sized buffers".to_string(),
        ));
    }

    // Use stream-aware copy for consistency with backend.stream()
    output.copy_from_buffer_with_stream(input, backend.stream().as_ptr())?;

    let handle = HipBlasHandle::new()
        .map_err(|e| HipError::GenericError(format!("Failed to create hipBLAS handle: {}", e)))?;
    set_stream(&handle, backend)?;

    let n = (output.size() / std::mem::size_of::<f32>()) as i32;
    hip_blas::sscal(
        &handle,
        n,
        factor,
        output.as_ptr() as *mut f32,
        1,
    )
    .map_err(|e| HipError::GenericError(format!("hipBLAS sscal failed: {}", e)))?;
    Ok(())
}
