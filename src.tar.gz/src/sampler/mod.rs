//! Sampler module for logits sampling

pub mod sampler;

pub use sampler::*;
